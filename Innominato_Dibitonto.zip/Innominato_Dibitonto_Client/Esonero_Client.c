/*
 #########################################
 Name        : Esonero_Client.c
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
 */

#if defined WIN32
#include <winsock2.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <string.h>
#include "Protocol.h"
#include <stdlib.h>

// Prototypes
void clearwinsock();
void errorhandler(char *errorMessage);
void generatePassword(int c_socket);

int main(void) {

#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != 0) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	// Create client socket
	int c_socket;
	c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_socket < 0) {
		errorhandler("Socket creation failed.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// Set connection settings
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr(PROTO_ADDR); // Server address
	sad.sin_port = htons(PROTO_PORT); // Server port
	puts("Welcome!");

	// Connect to the server
	if (connect(c_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("Failed to connect.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	printf("%s", "Connected to Server.\n\n");

	// Main client loop
	while (1) {
		generatePassword(c_socket); // Function to handle password generation requests
	}

	return 0;
}

// Function to generate password
void generatePassword(int c_socket) {
    char msg[BUFFER_SIZE];
    memset(msg, 0, sizeof(msg));  // Clear the buffer before each use

    // Get data from user
    printf("%s", "Select operation ([n|a|m|s] <length>) or 'q' to quit: ");
    fgets(msg, sizeof(msg), stdin);
    msg[strcspn(msg, "\n")] = '\0';  // Remove the newline character

    // If user chooses to quit
    if (msg[0] == 'q') {
        printf("Closing connection.\n");
        closesocket(c_socket);
        clearwinsock();
        exit(0);
    }

    // Add a newline (\n) to terminate the message
    strcat(msg, "\n");

    // Send data to server
    if (send(c_socket, msg, strlen(msg), 0) != strlen(msg)) {
        errorhandler("send() sent a different number of bytes than expected");
        closesocket(c_socket);
        clearwinsock();
        exit(-1);
    }

    // Clear buffer after sending
    memset(msg, 0, sizeof(msg));  // Clear the buffer before receiving data

    // Get reply from server
    int bytes_received = recv(c_socket, msg, sizeof(msg) - 1, 0);  // Limit the number of bytes read
    if (bytes_received <= 0) {
        errorhandler("recv() failed or connection closed prematurely");
        closesocket(c_socket);
        clearwinsock();
        exit(-1);
    }

    msg[bytes_received] = '\0';  // Ensure the received string is null-terminated

    // Print the password received
    printf("==> %s\n", msg);
}



// Function to clear Winsock (Windows-specific)
void clearwinsock() {
	#if defined WIN32
	WSACleanup();
	#endif
}

// Function to handle errors
void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);
}
