/*
 #########################################
 Name        : Protocol.h (Client)
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

// Server IP address and port
#define PROTO_ADDR "127.0.0.1"
#define PROTO_PORT 12345

// Buffer size for client-server communication
#define BUFFER_SIZE 256

// Queue length for incoming connections
#define QLEN 5

char msg[BUFFER_SIZE];

#endif /* PROTOCOL_H_ */
