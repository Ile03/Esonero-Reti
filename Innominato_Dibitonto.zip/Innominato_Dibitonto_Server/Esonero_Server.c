/*
 #########################################
 Name        : Esonero_Server.h
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
 */

#if defined WIN32
#include <winsock2.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Protocol.h"          // Include protocol definitions
#include "PasswordGenerator.h" // Include password generator functions

// Function prototypes
void clearwinsock();
void errorhandler(char *errorMessage);


int main(void) {
    #if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
    #endif

    // Initialize server socket
    int my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (my_socket < 0) {
        errorhandler("Socket creation failed.\n");
        clearwinsock();
        return -1;
    }

    // Set server address and port
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad)); // Clear structure
    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = inet_addr(PROTO_ADDR); // Use address from Protocol.h
    sad.sin_port = htons(PROTO_PORT);           // Use port from Protocol.h

    if (bind(my_socket, (struct sockaddr*)&sad, sizeof(sad)) < 0) {
        errorhandler("bind() failed.\n");
        closesocket(my_socket);
        clearwinsock();
        return -1;
    }

    // Listen for incoming connections
    if (listen(my_socket, QLEN) < 0) {
        errorhandler("listen() failed.\n");
        closesocket(my_socket);
        clearwinsock();
        return -1;
    }

    printf("Server is running and waiting for connections on %s:%d...\n", PROTO_ADDR, PROTO_PORT);

    // Accept and handle client connections
    struct sockaddr_in cad; // Client address
    int client_socket;      // Socket for client connection
    int client_len;         // Size of client address
    char msg[BUFFER_SIZE];  // Buffer for client messages

    while (1) {
        client_len = sizeof(cad);
        client_socket = accept(my_socket, (struct sockaddr*)&cad, &client_len);
        if (client_socket < 0) {
            errorhandler("accept() failed.\n");
            continue;
        }

        printf("New connection from %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

        while (1) {
            // Clear the buffer before receiving data
            memset(msg, 0, sizeof(msg));

            // Receive request from the client
            int bytes_received = recv(client_socket, msg, sizeof(msg) - 1, 0);
            if (bytes_received <= 0) {
                printf("Connection closed by client %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));
                break;
            }

            // Ensure the message is properly terminated
            msg[bytes_received] = '\0';

            // Remove any newline (\n) sent by the client
            msg[strcspn(msg, "\n")] = '\0';

            printf("Received request: %s\n", msg);

            // Check for the "q" command to close the connection
            if (strcmp(msg, "q") == 0) {
                printf("Client %s:%d requested to disconnect.\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));
                break;
            }

            // Parse the request (e.g., "n 8", "s 16")
            char type;
            int length;
            if (sscanf(msg, "%c %d", &type, &length) != 2 || length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
                snprintf(msg, BUFFER_SIZE - 1, "Invalid request. Use format 'n 8', 'a 12', 'm 10', or 's 16'. Length must be between %d and %d.",
                         MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
                msg[BUFFER_SIZE - 1] = '\0'; // Safe termination
                send(client_socket, msg, strlen(msg), 0);
                continue;
            }

            // Generate password based on the request
            char *password = NULL;
            switch (type) {
                case 'n':
                    password = generate_numeric(length);
                    break;
                case 'a':
                    password = generate_alpha(length);
                    break;
                case 'm':
                    password = generate_mixed(length);
                    break;
                case 's':
                    password = generate_secure(length);
                    break;
                default:
                    snprintf(msg, BUFFER_SIZE, "Invalid password type. Use 'n', 'a', 'm', or 's'.");
                    send(client_socket, msg, strlen(msg), 0);
                    continue;
            }

            // Send the generated password to the client
            if (password) {
                strncpy(msg, password, BUFFER_SIZE - 1); // Copy password to buffer
                msg[BUFFER_SIZE - 1] = '\0';            // Safe termination
                free(password);                         // Free allocated memory


                send(client_socket, msg, strlen(msg), 0);
            } else {
                snprintf(msg, BUFFER_SIZE, "Error generating password. Try again.");
                send(client_socket, msg, strlen(msg), 0);
            }
        }

        // Close client connection
        closesocket(client_socket);
    }

    // Clean up
    closesocket(my_socket);
    clearwinsock();
    return 0;
}

void clearwinsock() {
    #if defined WIN32
    WSACleanup();
    #endif
}

void errorhandler(char *errorMessage) {
    fprintf(stderr, "%s\n", errorMessage);
}
