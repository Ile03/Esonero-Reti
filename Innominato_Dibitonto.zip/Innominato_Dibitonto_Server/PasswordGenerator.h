/*
 #########################################
 Name        : PasswordGenerator.h
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
 */

#ifndef PASSWORDGENERATOR_H
#define PASSWORDGENERATOR_H

// Function prototypes for password generation
char *generate_numeric(int length);
char *generate_alpha(int length);
char *generate_mixed(int length);
char *generate_secure(int length);

#endif // PASSWORDGENERATOR_H
