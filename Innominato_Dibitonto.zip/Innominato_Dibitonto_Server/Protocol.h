/*
 #########################################
 Name        : Protocol.h (Server)
 Authors     : Ileana Pia Innominato, Michela Dibitonto
 #########################################
 */

#ifndef PROTOCOL_H
#define PROTOCOL_H

// Server IP address and port
#define PROTO_ADDR "127.0.0.1"
#define PROTO_PORT 12345

// Password constraints
#define MIN_PASSWORD_LENGTH 6
#define MAX_PASSWORD_LENGTH 32

// Buffer size for client-server communication
#define BUFFER_SIZE 256

// Queue length for incoming connections
#define QLEN 5

#endif // PROTOCOL_H
